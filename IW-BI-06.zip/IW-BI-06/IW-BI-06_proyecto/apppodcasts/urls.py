from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('podcasts/', views.index_podcasts, name='podcasts'),
    path('podcasts/<int:podcast_id>/', views.show_podcast, name='podcast'),
    path('tematicas/', views.index_tematicas, name='tematicas'),
    path('tematicas/<int:tematica_id>/', views.show_tematica, name='tematica'),
    path('plataformas/', views.index_plataformas, name='plataformas'),
    path('plataformas/<int:plataforma_id>/', views.show_plataforma, name='plataforma'),
]
