from django.apps import AppConfig


class ApppodcastsConfig(AppConfig):
    name = 'apppodcasts'
