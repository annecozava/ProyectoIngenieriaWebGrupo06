from django.db import models


class Tematica(models.Model):
    nombre = models.CharField(max_length=50)
    descripcion = models.TextField()

    #Coge objeto self y devuelve el nombre - por ejemplo coge el objeto 1 y lo llama humor
    def __str__(self):
        return self.nombre


class Plataforma(models.Model):
    nombre = models.CharField(max_length=50)
    web = models.URLField()

    #Coge objeto self y devuelve el nombre - por ejemplo coge el objeto 1 y lo llama youtube
    def __str__(self):
        return self.nombre


class Podcast(models.Model):
    #campo para la relacion one-to-many
    tematica = models.ForeignKey(Tematica, on_delete=models.CASCADE)
    #campo para la relacion many-to-many
    plataformas = models.ManyToManyField(Plataforma)
    nombre = models.CharField(max_length=80)
    descripcion = models.TextField()
    fecha = models.DateField()

    def __str__(self):
        return self.nombre
