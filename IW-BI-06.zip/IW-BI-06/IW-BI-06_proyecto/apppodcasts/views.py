from django.shortcuts import render, get_object_or_404
from .models import Tematica, Plataforma, Podcast


# portada: el podcast mas reciente de cada tematica
def index(request):
    destacados = []
    for t in Tematica.objects.order_by('nombre'):
        p = t.podcast_set.order_by('-fecha').first()
        if p:
            destacados.append(p)
    context = {'destacados': destacados}
    return render(request, 'index.html', context)


# lista de podcasts
def index_podcasts(request):
    podcasts = Podcast.objects.order_by('nombre')
    context = {'podcasts': podcasts}
    return render(request, 'podcasts.html', context)


# detalles de un podcast
def show_podcast(request, podcast_id):
    podcast = get_object_or_404(Podcast, pk=podcast_id)
    plataformas = podcast.plataformas.all()
    context = {'podcast': podcast, 'plataformas': plataformas}
    return render(request, 'podcast.html', context)


# lista de tematicas
def index_tematicas(request):
    tematicas = Tematica.objects.order_by('nombre')
    context = {'tematicas': tematicas}
    return render(request, 'tematicas.html', context)


# detalles de una tematica y sus podcasts
def show_tematica(request, tematica_id):
    tematica = get_object_or_404(Tematica, pk=tematica_id)
    podcasts = tematica.podcast_set.all()
    context = {'tematica': tematica, 'podcasts': podcasts}
    return render(request, 'tematica.html', context)


# lista de plataformas
def index_plataformas(request):
    plataformas = Plataforma.objects.order_by('nombre')
    context = {'plataformas': plataformas}
    return render(request, 'plataformas.html', context)


# detalles de una plataforma y sus podcasts
def show_plataforma(request, plataforma_id):
    plataforma = get_object_or_404(Plataforma, pk=plataforma_id)
    podcasts = plataforma.podcast_set.all()
    context = {'plataforma': plataforma, 'podcasts': podcasts}
    return render(request, 'plataforma.html', context)
