from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('apppodcasts/', include('apppodcasts.urls')),
    path('admin/', admin.site.urls),
]
